from setuptools import setup

setup(
   name='xodr_OSM_Converter',
   version='0.1.0',
   author='',
   author_email='',
   packages=['xodr_converter'],
   url=''
)
